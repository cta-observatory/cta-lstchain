import logging

import torch
import torch.nn as nn
import torch.nn.functional as F

import indexedconv.utils as utils
from indexedconv.engine import IndexedConv, IndexedMaxPool2d, IndexedAveragePool2d, MaskedConv2d


class CReLU(nn.Module):
    def __init__(self):
        super(CReLU, self).__init__()

    def forward(self, x):
        return torch.cat((F.relu(x), F.relu(-x)), 1)


class GLNet52MonoMultiOutCReLU(nn.Module):
    """
        Network with indexed convolutions and pooling.
        5 CL (after each conv layer, pooling is executed)
        3 FC
        Has as many in puts as telescopes (e.g. for LST with a selected layout, 4)
        Outputs of each telescope conv block are concatenated
    """

    def __init__(self, net_parameters_dic, camera_parameters, mode='train'):
        """

        Parameters
        ----------
        net_parameters_dic (dict): a dictionary describing the parameters of the network
        camera_parameters (dict): a dictionary containing the parameters of the camera used with this network
        mode (str): explicit mode to use the network (different from the nn.Module.train() or evaluate()). For GANs
        """
        super(GLNet52MonoMultiOutCReLU, self).__init__()
        self.logger = logging.getLogger(__name__ + '.GLNet52MonoMultiOutCReLU')
        camera_layout = camera_parameters['layout']
        pooling_kernel = camera_layout
        index_matrix1 = utils.create_index_matrix(camera_parameters['nbRow'],
                                                  camera_parameters['nbCol'],
                                                  camera_parameters['injTable'])

        # Channels
        n_features = net_parameters_dic['n_features']
        n1 = net_parameters_dic['num_channels']
        n2 = n_features * 2
        n3 = n2 * 2
        n4 = n3 * 2
        n5 = n4 * 2
        n_out_lin1 = net_parameters_dic['n_out_lin1']

        self.drop_rate = net_parameters_dic['drop_rate']
        batchnorm = net_parameters_dic['batchnorm']

        # Layer 1 : IndexedConv
        indices_conv1 = utils.neighbours_extraction(index_matrix1,
                                                    kernel_type=camera_layout)
        indices_pool1 = utils.neighbours_extraction(index_matrix1, kernel_type=pooling_kernel, stride=2)
        self.cv1 = IndexedConv(n1, n_features, indices_conv1)
        self.max_pool1 = IndexedMaxPool2d(indices_pool1)
        self.relu1 = CReLU()
        self.bn1 = nn.BatchNorm1d(n_features)

        # Layer 2 : IndexedConv
        index_matrix2 = utils.pool_index_matrix(index_matrix1, kernel_type=pooling_kernel, stride=2)
        indices_conv2 = utils.neighbours_extraction(index_matrix2,
                                                    kernel_type=camera_layout)
        indices_pool2 = utils.neighbours_extraction(index_matrix2, kernel_type=pooling_kernel, stride=2)
        self.cv2 = IndexedConv(n_features * 2, n2, indices_conv2)
        self.max_pool2 = IndexedMaxPool2d(indices_pool2)
        self.relu2 = CReLU()
        self.bn2 = nn.BatchNorm1d(n2)

        # Layer 3 : IndexedConv
        index_matrix3 = utils.pool_index_matrix(index_matrix2, kernel_type=pooling_kernel, stride=2)
        indices_conv3 = utils.neighbours_extraction(index_matrix3,
                                                    kernel_type=camera_layout)
        indices_pool3 = utils.neighbours_extraction(index_matrix3, kernel_type=pooling_kernel, stride=2)
        self.cv3 = IndexedConv(n2 * 2, n3, indices_conv3)
        self.max_pool3 = IndexedMaxPool2d(indices_pool3)
        self.relu3 = CReLU()
        self.bn3 = nn.BatchNorm1d(n3)

        # Layer 4 : IndexedConv
        index_matrix4 = utils.pool_index_matrix(index_matrix3, kernel_type=pooling_kernel, stride=2)
        indices_conv4 = utils.neighbours_extraction(index_matrix4,
                                                    kernel_type=camera_layout)
        indices_pool4 = utils.neighbours_extraction(index_matrix4, kernel_type=pooling_kernel, stride=2)
        self.cv4 = IndexedConv(n3 * 2, n4, indices_conv4)
        self.max_pool4 = IndexedMaxPool2d(indices_pool4)
        self.relu4 = CReLU()
        self.bn4 = nn.BatchNorm1d(n4)

        # Layer 5 : IndexedConv
        index_matrix5 = utils.pool_index_matrix(index_matrix4, kernel_type=pooling_kernel, stride=2)
        indices_conv5 = utils.neighbours_extraction(index_matrix5,
                                                    kernel_type=camera_layout)
        self.cv5 = IndexedConv(n4 * 2, n5, indices_conv5)
        self.relu5 = CReLU()
        self.bn5 = nn.BatchNorm1d(n5)

        # Compute the number of pixels (where idx is not -1 in the index matrix) of the last features
        n_pixels = int(torch.sum(torch.ge(index_matrix5[0, 0], 0)).data)
        self.logger.debug('num pixels after last conv : {}'.format(n_pixels))

        self.lin2_energy = nn.Linear(n5 * 2, n_out_lin1 // 2)
        self.relu6_energy = nn.ReLU()
        self.bn6_energy = nn.BatchNorm1d(n_out_lin1 // 2)

        self.lin2_impact = nn.Linear(n5 * 2, n_out_lin1 // 2)
        self.relu6_impact = nn.ReLU()
        self.bn6_impact = nn.BatchNorm1d(n_out_lin1 // 2)

        self.lin2_direction = nn.Linear(n5 * 2, n_out_lin1 // 2)
        self.relu6_direction = nn.ReLU()
        self.bn6_direction = nn.BatchNorm1d(n_out_lin1 // 2)

        self.lin3_energy = nn.Linear(n_out_lin1 // 2, 1)
        self.lin3_impact = nn.Linear(n_out_lin1 // 2, 2)
        self.lin3_direction = nn.Linear(n_out_lin1 // 2, 2)

        for m in self.modules():
            if isinstance(m, IndexedConv):
                nn.init.kaiming_uniform_(m.weight.data, mode='fan_out')

    def forward(self, x):
        drop = nn.Dropout(p=self.drop_rate)
        out = self.cv1(x)
        out = self.max_pool1(out)
        out = self.bn1(out)
        out = drop(self.relu1(out))

        out = self.cv2(out)
        out = self.max_pool2(out)
        out = self.bn2(out)
        out = drop(self.relu2(out))

        out = self.cv3(out)
        out = self.max_pool3(out)
        out = self.bn3(out)
        out = drop(self.relu3(out))

        out = self.cv4(out)
        out = self.max_pool4(out)
        out = self.bn4(out)
        out = drop(self.relu4(out))

        out = self.cv5(out)
        out, _ = torch.max(out, 2)  # Aggressive max pooling
        out = self.bn5(out)
        out = drop(self.relu5(out))

        out = out.view(out.size(0), -1)

        # Energy task
        out_e = self.lin2_energy(out)
        out_e = self.bn6_energy(out_e)
        out_e = drop(self.relu6_energy(out_e))
        out_e = self.lin3_energy(out_e)

        # Impact task
        out_i = self.lin2_impact(out)
        out_i = self.bn6_impact(out_i)
        out_i = drop(self.relu6_impact(out_i))
        out_i = self.lin3_impact(out_i)

        # Direction task
        out_d = self.lin2_direction(out)
        out_d = self.bn6_direction(out_d)
        out_d = drop(self.relu6_direction(out_d))
        out_d = self.lin3_direction(out_d)

        out = torch.cat((out_e, out_i, out_d), dim=1)

        return out

